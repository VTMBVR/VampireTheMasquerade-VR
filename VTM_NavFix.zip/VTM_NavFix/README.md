# VTM NavFix - Installation Guide

This package contains the fixed VScripts and navmesh files for the Vampire The Masquerade VR Asylum map.

Note - these fixes ar done for the `sm_asylum_fix_navfix.vmap` map.

---

## Contents

```
VTM_NavFix/
├── Nav files/
│   ├── sm_asylum_fix_navfix.nav
│   └── sm_asylum_fix_navfix.vpk
└── vscripts/
    ├── global_npc_placement.lua
    ├── interesting_place_club.lua
    └── vscript.globe.lua
```

---

## Installation

### Step 1 — Nav Files
Copy `sm_asylum_fix_navfix.nav` and `sm_asylum_fix_navfix.vpk` into:
```
Steam\steamapps\common\Half-Life Alyx\game\hlvr_addons\VampireTheMasquerade-VR\maps\
```

### Step 2 — VScripts
Copy the contents of the `vscripts` folder into:
```
Steam\steamapps\common\Half-Life Alyx\game\hlvr_addons\VampireTheMasquerade-VR\scripts\vscripts\
```
Replace existing files when prompted.

If the folder named `vscripts` doesnt exist then create it and paste the contents inside.

---